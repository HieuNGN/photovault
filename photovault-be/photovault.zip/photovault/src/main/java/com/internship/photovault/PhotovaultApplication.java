package com.internship.photovault;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhotovaultApplication {

	public static void main(String[] args) {
		SpringApplication.run(PhotovaultApplication.class, args);
	}

}
