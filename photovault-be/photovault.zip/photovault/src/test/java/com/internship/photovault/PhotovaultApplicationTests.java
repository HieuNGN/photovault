package com.internship.photovault;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotovaultApplicationTests {

	@Test
	void contextLoads() {
	}

}
